param(
    [string]$SptRoot,
    [switch]$NoPause
)

$ErrorActionPreference = "Stop"
$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ExitCode = 0
$BuildSucceeded = $false

try {
    Write-Host "============================================================="
    Write-Host " DynamicMaps Extended 1.5.0 - SPT 4.1.x Builder"
    Write-Host "============================================================="
    Write-Host ""
    Write-Host "This builder NEVER downloads map assets and NEVER installs files into SPT."
    Write-Host "All prepared artwork is bundled locally. Missing/corrupt bundled assets fail the build clearly."
    Write-Host ""

    if ([string]::IsNullOrWhiteSpace($SptRoot)) {
        $SptRoot = Read-Host "Enter your SPT 4.1.x root folder"
    }
    if ([string]::IsNullOrWhiteSpace($SptRoot)) { throw "No SPT folder was provided." }
    $SptRoot = [IO.Path]::GetFullPath($SptRoot.Trim('"'))
    if (-not (Test-Path -LiteralPath $SptRoot -PathType Container)) { throw "SPT folder does not exist: $SptRoot" }

    $dynamicMapsDll = Get-ChildItem -LiteralPath (Join-Path $SptRoot "BepInEx\plugins") -Filter "DynamicMaps.dll" -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $dynamicMapsDll) { throw "DynamicMaps.dll was not found under BepInEx\plugins." }
    $mapVariantsDll = Get-ChildItem -LiteralPath (Join-Path $SptRoot "BepInEx\plugins") -Filter "MapVariants.Client.dll" -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $mapVariantsDll) { throw "MapVariants.Client.dll was not found under BepInEx\plugins." }

    Write-Host "DynamicMaps: $($dynamicMapsDll.FullName)"
    Write-Host "MapVariants: $($mapVariantsDll.FullName)"

    # The high-resolution tile renderer uses RectTransformUtility, Canvas and CanvasRenderer,
    # which are type-forwarded to UnityEngine.UIModule in current EFT/Unity builds.
    $uiModuleDll = Join-Path $SptRoot "EscapeFromTarkov_Data\Managed\UnityEngine.UIModule.dll"
    if (-not (Test-Path -LiteralPath $uiModuleDll -PathType Leaf)) {
        throw "UnityEngine.UIModule.dll was not found: $uiModuleDll"
    }
    Write-Host "Unity UI:    $uiModuleDll"

    # Validate only extension-owned static MapDef assets. DMROOT/* explicitly references
    # DynamicMaps' own bundled artwork and therefore must not be copied into this project.
    $mapsRoot = Join-Path $SourceRoot "Maps"
    if (-not (Test-Path -LiteralPath $mapsRoot -PathType Container)) { throw "Maps folder is missing." }

    $mapDefFiles = Get-ChildItem -LiteralPath $mapsRoot -Filter "*.jsonc" -File -Recurse
    foreach ($mapDefFile in $mapDefFiles) {
        try { $mapDef = Get-Content -LiteralPath $mapDefFile.FullName -Raw | ConvertFrom-Json }
        catch { throw "Invalid map definition: $($mapDefFile.FullName) : $($_.Exception.Message)" }

        $missingAssets = New-Object System.Collections.Generic.List[string]
        foreach ($layerProp in $mapDef.Layers.PSObject.Properties) {
            $imagePath = [string]$layerProp.Value.ImagePath

            if ($imagePath.StartsWith("DMROOT/", [StringComparison]::OrdinalIgnoreCase)) {
                $nativeRel = $imagePath.Substring(7).Replace('/', [IO.Path]::DirectorySeparatorChar)
                $nativeAsset = Join-Path $dynamicMapsDll.Directory.FullName $nativeRel
                if (-not (Test-Path -LiteralPath $nativeAsset -PathType Leaf) -or (Get-Item -LiteralPath $nativeAsset).Length -eq 0) {
                    throw "Required DynamicMaps artwork referenced by $($mapDefFile.Name) is missing: $nativeAsset"
                }
                continue
            }

            if (-not $imagePath.StartsWith("Maps/", [StringComparison]::OrdinalIgnoreCase)) {
                throw "Unexpected image path in $($mapDefFile.FullName): $imagePath"
            }

            $sourceRel = $imagePath.Substring(5).Replace('/', [IO.Path]::DirectorySeparatorChar)
            $assetPath = Join-Path $mapsRoot $sourceRel
            if (-not (Test-Path -LiteralPath $assetPath -PathType Leaf) -or (Get-Item -LiteralPath $assetPath).Length -eq 0) {
                $missingAssets.Add($assetPath)
            }
        }

        if ($missingAssets.Count -gt 0) {
            throw "Bundled map asset is missing: $($missingAssets[0])"
        }

        # Every prepared extension-owned raster MapDef uses a sibling high-resolution tile pack.
        # Factory Classic predates the tiled renderer and intentionally remains PNG-only.
        foreach ($layerProp in $mapDef.Layers.PSObject.Properties) {
            $imagePath = [string]$layerProp.Value.ImagePath
            if (-not $imagePath.StartsWith("Maps/", [StringComparison]::OrdinalIgnoreCase)) { continue }
            if (-not $imagePath.EndsWith(".png", [StringComparison]::OrdinalIgnoreCase)) { continue }
            if ($imagePath.IndexOf("/Factory_Classic/", [StringComparison]::OrdinalIgnoreCase) -ge 0) { continue }

            $sourceRel = $imagePath.Substring(5).Replace('/', [IO.Path]::DirectorySeparatorChar)
            $assetPath = Join-Path $mapsRoot $sourceRel
            $tilePath = [IO.Path]::ChangeExtension($assetPath, ".tiles")
            if (-not (Test-Path -LiteralPath $tilePath -PathType Leaf) -or (Get-Item -LiteralPath $tilePath).Length -le 40) {
                throw "Bundled high-resolution tile pack is missing/empty: $tilePath"
            }
        }
    }

    # Factory Classic is a static extension map and must always be complete in source packages.
    $factoryClassicRequired = @(
        "Factory_Classic\Factory_Classic.jsonc",
        "Factory_Classic\Layers\factory_layer_-1.png",
        "Factory_Classic\Layers\factory_layer_0.png",
        "Factory_Classic\Layers\factory_layer_1.png",
        "Factory_Classic\Layers\factory_layer_2.png"
    )
    foreach ($rel in $factoryClassicRequired) {
        $p = Join-Path $mapsRoot $rel
        if (-not (Test-Path -LiteralPath $p -PathType Leaf) -or (Get-Item -LiteralPath $p).Length -eq 0) {
            throw "Required Factory Classic file is missing: $p"
        }
    }

    # Validate the complete prepared raster catalog, including style-only assets that are not
    # referenced directly by an extension MapDef. This is deliberately offline and checks the
    # expected file sizes plus the NVTILES2 magic rather than downloading/preparing anything.
    $bundleManifestPath = Join-Path $mapsRoot "BUNDLED-RASTER-ASSETS.json"
    if (-not (Test-Path -LiteralPath $bundleManifestPath -PathType Leaf)) {
        throw "Bundled raster manifest is missing: $bundleManifestPath"
    }
    try { $bundleManifest = Get-Content -LiteralPath $bundleManifestPath -Raw | ConvertFrom-Json }
    catch { throw "Invalid bundled raster manifest: $($_.Exception.Message)" }

    $bundleAssets = @($bundleManifest.assets)
    if ($bundleAssets.Count -ne 42) {
        throw "Bundled raster manifest should contain 42 layer pairs, found $($bundleAssets.Count)."
    }

    foreach ($asset in $bundleAssets) {
        $preview = Join-Path $SourceRoot ([string]$asset.outputPreview).Replace('/', [IO.Path]::DirectorySeparatorChar)
        $pack = Join-Path $SourceRoot ([string]$asset.outputPack).Replace('/', [IO.Path]::DirectorySeparatorChar)

        if (-not (Test-Path -LiteralPath $preview -PathType Leaf)) { throw "Bundled raster preview is missing: $preview" }
        if (-not (Test-Path -LiteralPath $pack -PathType Leaf)) { throw "Bundled raster tile pack is missing: $pack" }

        $previewLength = (Get-Item -LiteralPath $preview).Length
        $packLength = (Get-Item -LiteralPath $pack).Length
        if ($previewLength -ne [int64]$asset.previewBytes) { throw "Bundled preview size mismatch/corruption: $preview" }
        if ($packLength -ne [int64]$asset.packBytes) { throw "Bundled tile-pack size mismatch/corruption: $pack" }

        [byte[]]$magicBytes = Get-Content -LiteralPath $pack -Encoding Byte -TotalCount 8
        $magic = [Text.Encoding]::ASCII.GetString($magicBytes)
        if ($magic -ne "NVTILES2") { throw "Bundled tile pack has invalid magic '$magic': $pack" }
    }
    Write-Host "Validated 42 bundled raster preview/tile-pack pairs." -ForegroundColor Green

    # Validate the calibration snapshot used to keep Satellite artwork in its own authoritative
    # world-coordinate rectangle instead of stretching it into an unrelated SVG rectangle.
    $calibrationPath = Join-Path $mapsRoot "Provenance\RASTER-CALIBRATION.json"
    if (-not (Test-Path -LiteralPath $calibrationPath -PathType Leaf)) {
        throw "Raster calibration manifest is missing: $calibrationPath"
    }
    try { $calibration = Get-Content -LiteralPath $calibrationPath -Raw | ConvertFrom-Json }
    catch { throw "Invalid raster calibration manifest: $($_.Exception.Message)" }
    if (@($calibration.assets).Count -ne 42) {
        throw "Raster calibration manifest should contain 42 layers, found $(@($calibration.assets).Count)."
    }
    Write-Host "Validated 42 raster calibration records." -ForegroundColor Green

    # Validate the pinned SVG source snapshot that is bundled with the source/release.
    # Runtime does not fetch these files; they are retained locally for provenance and future
    # layer preparation, while current DynamicMaps-native SVG artwork remains authoritative
    # where the base plugin already ships verified split layers.
    $svgRoot = Join-Path $mapsRoot "TarkovDev-SVG"
    $svgRequired = @(
        "Customs.svg", "Factory.svg", "GroundZero.svg", "Interchange.svg",
        "Labs.svg", "Lighthouse.svg", "Reserve.svg", "Shoreline.svg",
        "StreetsOfTarkov.svg", "Terminal.svg", "Woods.svg", "LICENSE.md"
    )
    foreach ($name in $svgRequired) {
        $svgPath = Join-Path $svgRoot $name
        if (-not (Test-Path -LiteralPath $svgPath -PathType Leaf) -or (Get-Item -LiteralPath $svgPath).Length -eq 0) {
            throw "Bundled Tarkov.dev SVG snapshot file is missing/empty: $svgPath"
        }
    }
    Write-Host "Validated bundled Tarkov.dev SVG snapshot ($($svgRequired.Count) files)." -ForegroundColor Green

    # Manimal Interchange's MapDef still uses these tiny split SVGs as stable source-path anchors
    # so Vanilla/Satellite/Abstract can be resolved from one logical map. They are NOT rendered for
    # the Abstract choice anymore; Unity.VectorGraphics misrenders that current tarkov.dev export.
    $manimalAnchorRequired = @(
        "Interchange_Backport\Abstract\Interchange-Ground.svg",
        "Interchange_Backport\Abstract\Interchange-First.svg",
        "Interchange_Backport\Abstract\Interchange-Second.svg"
    )
    foreach ($rel in $manimalAnchorRequired) {
        $p = Join-Path $mapsRoot $rel
        if (-not (Test-Path -LiteralPath $p -PathType Leaf) -or (Get-Item -LiteralPath $p).Length -eq 0) {
            throw "Manimal Interchange source-path anchor is missing/empty: $p"
        }
    }

    # The verified Manimal Abstract artwork is rasterized OFFLINE from the pinned current SVG and
    # streams from local preview + high-resolution NVTILES1 packs at runtime. This deliberately
    # bypasses Unity.VectorGraphics for this artwork while preserving the correct Manimal bounds.
    $manimalAbstractRaster = @(
        "Interchange-Ground", "Interchange-First", "Interchange-Second"
    )
    foreach ($name in $manimalAbstractRaster) {
        $preview = Join-Path $mapsRoot ("Interchange_Backport\AbstractRaster\" + $name + ".png")
        $pack = Join-Path $mapsRoot ("Interchange_Backport\AbstractRaster\" + $name + ".tiles")
        if (-not (Test-Path -LiteralPath $preview -PathType Leaf) -or (Get-Item -LiteralPath $preview).Length -eq 0) {
            throw "Manimal Interchange Abstract preview is missing/empty: $preview"
        }
        if (-not (Test-Path -LiteralPath $pack -PathType Leaf) -or (Get-Item -LiteralPath $pack).Length -le 24) {
            throw "Manimal Interchange Abstract tile pack is missing/empty: $pack"
        }
        [byte[]]$magicBytes = Get-Content -LiteralPath $pack -Encoding Byte -TotalCount 8
        $magic = [Text.Encoding]::ASCII.GetString($magicBytes)
        if ($magic -ne "NVTILES1") { throw "Manimal Interchange Abstract pack has invalid magic '$magic': $pack" }
    }
    Write-Host "Validated Manimal Interchange Abstract raster layers (3 preview/tile-pack pairs)." -ForegroundColor Green

    # FIX-10C: validate the medium-resolution whole-floor atlases that are cached quietly after
    # raid start. Only one atlas is decoded for the current raid/style; these files are not a
    # startup-wide preload and they never replace the max-resolution .tiles source.
    $warmManifestPath = Join-Path $mapsRoot "WARM-CACHE-ASSETS.json"
    if (-not (Test-Path -LiteralPath $warmManifestPath -PathType Leaf)) {
        throw "Raid warm-cache manifest is missing: $warmManifestPath"
    }
    try { $warmManifest = Get-Content -LiteralPath $warmManifestPath -Raw | ConvertFrom-Json }
    catch { throw "Invalid raid warm-cache manifest: $($_.Exception.Message)" }

    $warmAssets = @($warmManifest.assets)
    if ($warmAssets.Count -ne 11) {
        throw "Raid warm-cache manifest should contain 11 whole-floor atlases, found $($warmAssets.Count)."
    }

    foreach ($asset in $warmAssets) {
        $warmPath = Join-Path $SourceRoot ([string]$asset.warm).Replace('/', [IO.Path]::DirectorySeparatorChar)
        if (-not (Test-Path -LiteralPath $warmPath -PathType Leaf)) { throw "Raid warm atlas is missing: $warmPath" }
        if ((Get-Item -LiteralPath $warmPath).Length -ne [int64]$asset.bytes) { throw "Raid warm atlas size mismatch/corruption: $warmPath" }
        [byte[]]$pngHeader = Get-Content -LiteralPath $warmPath -Encoding Byte -TotalCount 8
        if ($pngHeader.Length -ne 8 -or $pngHeader[0] -ne 137 -or $pngHeader[1] -ne 80 -or $pngHeader[2] -ne 78 -or $pngHeader[3] -ne 71) {
            throw "Raid warm atlas is not a valid PNG file: $warmPath"
        }
    }
    Write-Host "Validated 11 raid-start whole-floor warm atlases (max 3072px long edge)." -ForegroundColor Green

    # Validate only the remaining SVG Abstract layers that are meaningful runtime choices. Duplicate
    # copies equivalent to DynamicMaps Vanilla are deliberately excluded from release builds.
    $abstractRequired = @(
        "StyleAssets\Factory\Abstract\Factory-Ground.svg",
        "StyleAssets\Factory\Abstract\Factory-Second.svg",
        "StyleAssets\Factory\Abstract\Factory-Third.svg",
        "StyleAssets\Factory\Abstract\Factory-Tunnels.svg",
        "StyleAssets\Woods\Abstract\Woods-Ground.svg",
        "StyleAssets\Streets\Abstract\Streets-Ground.svg",
        "StyleAssets\Streets\Abstract\Streets-Underground.svg",
        "StyleAssets\Streets\Abstract\Streets-Second.svg",
        "StyleAssets\Streets\Abstract\Streets-Third.svg",
        "StyleAssets\Streets\Abstract\Streets-Fourth.svg",
        "StyleAssets\Streets\Abstract\Streets-Fifth.svg"
    )
    foreach ($rel in $abstractRequired) {
        $p = Join-Path $mapsRoot $rel
        if (-not (Test-Path -LiteralPath $p -PathType Leaf) -or (Get-Item -LiteralPath $p).Length -eq 0) {
            throw "Bundled Abstract map artwork is missing/empty: $p"
        }
    }
    Write-Host "Validated meaningful bundled Abstract SVG layers ($($abstractRequired.Count) files)." -ForegroundColor Green

    Write-Host ""
    Write-Host "Building plugin against: $SptRoot"
    $project = Join-Path $SourceRoot "DynamicMaps.Extended.csproj"
    & dotnet build $project -c Release "-p:SptRoot=$SptRoot"
    if ($LASTEXITCODE -ne 0) { throw "dotnet build failed." }

    $dll = Join-Path $SourceRoot "bin\Release\netstandard2.1\DynamicMaps.Extended.dll"
    if (-not (Test-Path -LiteralPath $dll)) { throw "Build succeeded but DLL was not found: $dll" }

    $releaseRoot = Join-Path $SourceRoot "release"
    $stageRoot = Join-Path $releaseRoot "DynamicMaps-Extended"
    if (Test-Path -LiteralPath $stageRoot) { Remove-Item -LiteralPath $stageRoot -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $stageRoot | Out-Null

    $pluginOut = Join-Path $stageRoot "BepInEx\plugins\DynamicMaps-Extended"
    $mapsOut = Join-Path $pluginOut "Maps"
    New-Item -ItemType Directory -Force -Path $mapsOut | Out-Null

    Copy-Item -LiteralPath $dll -Destination $pluginOut
    Get-ChildItem -LiteralPath $mapsRoot -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $mapsOut -Recurse -Force
    }

    # Final runtime package is intentionally lean. Keep source/provenance material in the source
    # tree, but do not ship duplicate Abstract art that is identical to DynamicMaps Vanilla.
    $releaseRemove = @(
        "TarkovDev-SVG",
        "Provenance",
        "StyleAssets\GroundZero\Abstract",
        "StyleAssets\Customs\Abstract",
        "StyleAssets\Interchange\Abstract",
        "StyleAssets\Lighthouse\Abstract",
        "StyleAssets\Reserve\Abstract",
        "StyleAssets\Shoreline\Abstract"
    )
    foreach ($rel in $releaseRemove) {
        $p = Join-Path $mapsOut $rel
        if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Recurse -Force }
    }

    Copy-Item -LiteralPath (Join-Path $SourceRoot "README.md") -Destination $pluginOut
    Copy-Item -LiteralPath (Join-Path $SourceRoot "LICENSE") -Destination $pluginOut
    Copy-Item -LiteralPath (Join-Path $SourceRoot "THIRD-PARTY.md") -Destination $pluginOut

    if (-not (Test-Path -LiteralPath $releaseRoot)) { New-Item -ItemType Directory -Force -Path $releaseRoot | Out-Null }
    $zip = Join-Path $releaseRoot "DynamicMaps-Extended-1.5.0-SPT4.1.zip"
    if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
    Compress-Archive -Path (Join-Path $stageRoot "*") -DestinationPath $zip -Force

    Write-Host ""
    Write-Host "BUILD COMPLETE"
    Write-Host "Release ZIP: $zip"
    Write-Host "No network/download step was used."
    $BuildSucceeded = $true
}
catch {
    $ExitCode = 1
    Write-Host ""
    Write-Host "=============================================================" -ForegroundColor Red
    Write-Host " BUILD FAILED" -ForegroundColor Red
    Write-Host "=============================================================" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    if ($_.InvocationInfo -and $_.InvocationInfo.PositionMessage) {
        Write-Host ""
        Write-Host $_.InvocationInfo.PositionMessage
    }
}
finally {
    Write-Host ""
    if ($BuildSucceeded) {
        Write-Host "=============================================================" -ForegroundColor Green
        Write-Host " BUILD SUCCEEDED" -ForegroundColor Green
        Write-Host "=============================================================" -ForegroundColor Green
    }
    if (-not $NoPause) { [void](Read-Host "Press ENTER to close this window") }
}
if ($ExitCode -ne 0) { exit $ExitCode }
