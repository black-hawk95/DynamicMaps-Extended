using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace DynamicMapsExtended
{
    // The extra selector only exists in Character -> Maps. Raid selection remains exclusively
    // MapVariants/FactoryClassic -> the existing alias filter. Uses the native DropDownBox prefab.
    internal sealed class LogicalVariantSelector : MonoBehaviour
    {
        private object _host, _dropdown;
        private Component _native;
        private GameObject _view;
        private IDisposable _subscription;
        private List<object> _variants = new();
        private bool _updating;

        private static object NativeCall(object target, string name, params object[] args)
        {
            var method = target.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                .Where(m => m.Name == name && !m.ContainsGenericParameters)
                .FirstOrDefault(m =>
                {
                    var p = m.GetParameters();
                    return p.Length >= args.Length && p.Skip(args.Length).All(v => v.HasDefaultValue) &&
                        p.Take(args.Length).Select((v, i) => args[i] == null || v.ParameterType.IsInstanceOfType(args[i])).All(v => v);
                }) ?? throw new MissingMethodException(target.GetType().FullName, name);
            var parameters = method.GetParameters();
            var values = new object[parameters.Length];
            Array.Copy(args, values, args.Length);
            for (var i = args.Length; i < values.Length; i++) values[i] = parameters[i].DefaultValue;
            return method.Invoke(target, values);
        }

        internal static string Group(object def)
        {
            if (def == null) return null;
            var names = AccessTools.Property(def.GetType(), "MapInternalNames")?.GetValue(def) as IEnumerable;
            if (names == null) return null;
            foreach (var n in names)
            {
                var s = n?.ToString()?.ToLowerInvariant();
                if (s == "interchange" || s == MapAliasPatch.InterchangeAlias) return "Interchange";
                if (s == "laboratory" || s == MapAliasPatch.LabsAlias) return "The Lab";
                if (s == "factory4_day" || s == "factory4_night" || s == MapAliasPatch.FactoryClassicAlias) return "Factory";
                if (s == "rezervbase" || s == "reserve" || s == "dmext_reserve_expanded") return "Reserve";
                if (s == "labyrinth" || s == "dmext_labyrinth_tiles") return "Labyrinth";
            }
            return null;
        }
        internal static bool Alias(object def)
        {
            var names = AccessTools.Property(def.GetType(), "MapInternalNames")?.GetValue(def) as IEnumerable;
            return names != null && names.Cast<object>().Any(n => n?.ToString()?.StartsWith("dmext_", StringComparison.OrdinalIgnoreCase) == true);
        }
        internal static bool RaidFiltered(object host)
            => !string.IsNullOrEmpty(AccessTools.Field(host.GetType(), "_nameFilter")?.GetValue(host) as string);

        internal static void Selected(object host, object def)
        {
            if (!(host is Component c)) return;
            var selector = c.GetComponent<LogicalVariantSelector>() ?? c.gameObject.AddComponent<LogicalVariantSelector>();
            selector._host = host;
            selector.Show(def);
        }
        private void Show(object def)
        {
            var group = Group(def);
            if (RaidFiltered(_host) || group == null || group == "Reserve" || group == "Labyrinth") { Hide(); return; }
            var defs = AccessTools.Field(_host.GetType(), "_mapDefs")?.GetValue(_host) as IDictionary;
            _variants = defs?.Values.Cast<object>().Where(d => Group(d) == group).OrderBy(Alias).ToList() ?? new();
            if (_variants.Count < 2) { Hide(); return; }
            if (_view == null && !CreateView()) return;
            _updating = true;
            try
            {
                _view.SetActive(true);
                var labels = _variants.Select(d => !Alias(d) ? (group == "Factory" ? "Current" : "Vanilla") :
                    group == "Factory" ? "Classic" : group == "The Lab" ? "Manimal Expansion" : "Manimal").ToArray();
                NativeCall(_dropdown, "Show", (object)labels);
                NativeCall(_dropdown, "UpdateValue", Math.Max(0, _variants.IndexOf(def)));
            }
            finally { _updating = false; }
        }
        private bool CreateView()
        {
            try
            {
                _native = AccessTools.Field(_host.GetType(), "_dropdown")?.GetValue(_host) as Component;
                if (_native == null || !(_native.transform is RectTransform original)) return false;
                _view = Instantiate(_native.gameObject, original.parent, false);
                _view.name = "DMExt Map Variant";
                var rect = (RectTransform)_view.transform;
                rect.anchoredPosition = original.anchoredPosition + new Vector2(0, -original.rect.height - 4);
                _dropdown = _view.GetComponent(_native.GetType());
                NativeCall(_dropdown, "SetLabelText", "Variant");
                var signal = AccessTools.Property(_dropdown.GetType(), "OnValueChanged")?.GetValue(_dropdown)
                    ?? AccessTools.Field(_dropdown.GetType(), "OnValueChanged")?.GetValue(_dropdown);
                if (signal == null) throw new MissingMemberException("Native dropdown value signal missing");
                Action<int> callback = Changed;
                // BSG has shipped both instance and extension Subscribe implementations.
                var instance = signal.GetType().GetMethods().FirstOrDefault(m => m.Name == "Subscribe" &&
                    m.GetParameters().Length == 1 && m.GetParameters()[0].ParameterType.IsInstanceOfType(callback));
                if (instance != null) _subscription = instance.Invoke(signal, new object[] { callback }) as IDisposable;
                else if (signal is IObservable<int> observable) _subscription = observable.Subscribe(new Observer(callback));
                else
                {
                    var attached = false;
                    foreach (var assembly in new[] { signal.GetType().Assembly, _dropdown.GetType().Assembly }.Distinct())
                    {
                        Type[] types;
                        try { types = assembly.GetTypes(); } catch (ReflectionTypeLoadException e) { types = e.Types.Where(t => t != null).ToArray(); }
                        foreach (var type in types.Where(t => t.IsAbstract && t.IsSealed))
                        {
                            foreach (var method in type.GetMethods(BindingFlags.Public | BindingFlags.Static).Where(m => m.Name == "Subscribe"))
                            {
                                MethodInfo m = method;
                                if (m.IsGenericMethodDefinition)
                                {
                                    if (m.GetGenericArguments().Length != 1) continue;
                                    try { m = m.MakeGenericMethod(typeof(int)); } catch { continue; }
                                }
                                var p = m.GetParameters();
                                if (p.Length < 2 || !p[0].ParameterType.IsInstanceOfType(signal) || !p[1].ParameterType.IsInstanceOfType(callback) || p.Skip(2).Any(v => !v.HasDefaultValue)) continue;
                                var args = p.Select(v => v.DefaultValue).ToArray(); args[0] = signal; args[1] = callback;
                                _subscription = m.Invoke(null, args) as IDisposable; attached = true; break;
                            }
                            if (attached) break;
                        }
                        if (attached) break;
                    }
                    if (!attached) throw new MissingMethodException("Native dropdown Subscribe API unsupported");
                }
                return true;
            }
            catch (Exception e)
            {
                if (_view != null) Destroy(_view); _view = null;
                Plugin.Log.LogWarning("Could not create the native variant selector: " + e.Message);
                return false;
            }
        }
        private void Changed(int index)
        {
            if (_updating || index < 0 || index >= _variants.Count || RaidFiltered(_host)) return;
            var callback = AccessTools.Field(_host.GetType(), "OnMapSelected")?.GetValue(_host) as Delegate;
            callback?.DynamicInvoke(_variants[index]);
        }
        private void Hide() { if (_view != null) _view.SetActive(false); }
        private void OnDestroy() { _subscription?.Dispose(); if (_view != null) Destroy(_view); }
        private sealed class Observer : IObserver<int>
        {
            private readonly Action<int> _action;
            internal Observer(Action<int> action) { _action = action; }
            public void OnNext(int v) => _action(v);
            public void OnError(Exception e) { }
            public void OnCompleted() { }
        }
    }

    [HarmonyPatch]
    internal static class LogicalVariantLoadPatch
    {
        private static MethodBase TargetMethod() => AccessTools.Method(AccessTools.TypeByName("DynamicMaps.UI.Controls.MapSelectDropdown"), "OnLoadMap");
        private static void Prefix(object __instance, object[] __args)
        {
            if (__args.Length == 0 || LogicalVariantSelector.RaidFiltered(__instance)) return;
            var original = __args[0];
            LogicalVariantSelector.Selected(__instance, original);
            // Alias MapDefs are deliberately absent from the logical map list. Synchronise its
            // native dropdown with the logical representative, instead of UpdateValue(-1).
            if (!LogicalVariantSelector.Alias(original)) return;
            var defs = AccessTools.Field(__instance.GetType(), "_selectableMapDefs")?.GetValue(__instance) as IEnumerable;
            var representative = defs?.Cast<object>().FirstOrDefault(d => LogicalVariantSelector.Group(d) == LogicalVariantSelector.Group(original));
            if (representative != null) __args[0] = representative;
        }
    }
}
