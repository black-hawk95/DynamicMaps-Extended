using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace DynamicMapsExtended
{
    internal static class ExpandedArtworkDefinitions
    {
        internal static string ResolveAlias(string name)
        {
            if ((string.Equals(name, "Reserve", StringComparison.OrdinalIgnoreCase) || string.Equals(name, "RezervBase", StringComparison.OrdinalIgnoreCase)) &&
                MapStyleManager.RequestedFor(MapStyleKey.Reserve) != MapArtMode.Original && ReserveReady())
                return "dmext_reserve_expanded";
            if (string.Equals(name, "Labyrinth", StringComparison.OrdinalIgnoreCase) &&
                MapStyleManager.RequestedFor(MapStyleKey.Labyrinth) != MapArtMode.Original &&
                ArtworkCatalog.Available("Maps/StyleAssets/Labyrinth/Satellite/Labyrinth-Ground.png"))
                return "dmext_labyrinth_tiles";
            return name;
        }
        private static bool ReserveReady() => new[] { "Second", "Third", "Fourth", "Fifth" }.All(f =>
            ArtworkCatalog.Available("Maps/StyleAssets/Reserve/Satellite/Reserve-" + f + ".png"));
        internal static object ResolveMenu(object host, object native)
        {
            var names = AccessTools.Property(native.GetType(), "MapInternalNames")?.GetValue(native) as IEnumerable;
            if (names == null) return native;
            string alias = null;
            foreach (var n in names)
            {
                var name = n?.ToString();
                var resolved = ResolveAlias(name);
                if (resolved != name) { alias = resolved; break; }
            }
            if (alias == null) return native;
            var defs = AccessTools.Field(host.GetType(), "_mapDefs")?.GetValue(host) as IDictionary;
            return defs?.Values.Cast<object>().FirstOrDefault(d =>
                (AccessTools.Property(d.GetType(), "MapInternalNames")?.GetValue(d) as IEnumerable)?.Cast<object>()
                    .Any(n => string.Equals(n?.ToString(), alias, StringComparison.OrdinalIgnoreCase)) == true) ?? native;
        }

        internal static void RefreshForSettings()
        {
            // A provider requiring a distinct MapDef (extra Reserve floors / rotated Labyrinth)
            // must return to the truly native MapDef when Original is selected. Delegate the
            // change through DynamicMaps' own dropdown event; do not change coordinate routines.
            var type = AccessTools.TypeByName("DynamicMaps.UI.ModdedMapScreen");
            if (type == null) return;
            foreach (var screen in Resources.FindObjectsOfTypeAll(type))
            {
                try
                {
                    var view = AccessTools.Field(type, "_mapView")?.GetValue(screen);
                    var current = view == null ? null : AccessTools.Property(view.GetType(), "CurrentMapDef")?.GetValue(view);
                    if (current == null) continue;
                    var group = LogicalVariantSelector.Group(current);
                    if (group != "Reserve" && group != "Labyrinth") continue;
                    var host = AccessTools.Field(type, "_mapSelectDropdown")?.GetValue(screen);
                    if (host == null) continue;
                    var defs = AccessTools.Field(host.GetType(), "_mapDefs")?.GetValue(host) as IDictionary;
                    var native = defs?.Values.Cast<object>().FirstOrDefault(d => !LogicalVariantSelector.Alias(d) && LogicalVariantSelector.Group(d) == group);
                    if (native == null) continue;
                    var desired = ResolveMenu(host, native);
                    if (ReferenceEquals(current, desired)) continue;
                    if (LogicalVariantSelector.RaidFiltered(host))
                    {
                        var names = AccessTools.Property(native.GetType(), "MapInternalNames")?.GetValue(native) as IEnumerable;
                        var name = names?.Cast<object>().FirstOrDefault()?.ToString();
                        if (name == null) continue;
                        AccessTools.Method(host.GetType(), "FilterByInternalMapName")?.Invoke(host, new object[] { name });
                        AccessTools.Method(host.GetType(), "LoadFirstAvailableMap")?.Invoke(host, null);
                    }
                    else
                    {
                        var callback = AccessTools.Field(host.GetType(), "OnMapSelected")?.GetValue(host) as Delegate;
                        callback?.DynamicInvoke(desired);
                    }
                }
                catch (Exception e) { Plugin.Log.LogWarning("Could not refresh artwork MapDef: " + e.Message); }
            }
        }
    }

    [HarmonyPatch]
    internal static class ExpandedMenuArtworkPatch
    {
        private static MethodBase TargetMethod() => AccessTools.Method(
            AccessTools.TypeByName("DynamicMaps.UI.Controls.MapSelectDropdown"), "OnSelectDropdownMap");
        private static bool Prefix(object __instance, int __0)
        {
            if (LogicalVariantSelector.RaidFiltered(__instance)) return true;
            var list = AccessTools.Field(__instance.GetType(), "_selectableMapDefs")?.GetValue(__instance) as IList;
            if (list == null || __0 < 0 || __0 >= list.Count) return true;
            var source = list[__0]; var resolved = ExpandedArtworkDefinitions.ResolveMenu(__instance, source);
            if (ReferenceEquals(source, resolved)) return true;
            var action = AccessTools.Field(__instance.GetType(), "OnMapSelected")?.GetValue(__instance) as Delegate;
            if (action == null) return true;
            action.DynamicInvoke(resolved);
            return false;
        }
    }
}
