using System;
using System.Reflection;
using System.Collections.Generic;
using HarmonyLib;

namespace DynamicMapsExtended
{
    // Intentionally patch ONLY the dropdown filter. We do not alter
    // GameUtils.GetCurrentMapInternalName(), so DynamicMaps' map-item checks,
    // dump filenames, live player tracking, quest markers and every other
    // subsystem keep the real EFT location ID.
    [HarmonyPatch]
    internal static class MapAliasPatch
    {
        internal const string InterchangeAlias = "dmext_interchange_backport";
        internal const string LabsAlias = "dmext_laboratory_backport";
        internal const string FactoryClassicAlias = "dmext_factory_classic";

        private static readonly HashSet<string> LoggedAliasDecisions = new HashSet<string>(StringComparer.Ordinal);

        private static void DebugOnce(string key, string message)
        {
            if (!Plugin.DebugEnabled) return;
            if (LoggedAliasDecisions.Add(key))
                Plugin.Debug(message);
        }

        private static MethodBase TargetMethod()
        {
            var type = AccessTools.TypeByName("DynamicMaps.UI.Controls.MapSelectDropdown")
                ?? throw new MissingMemberException("DynamicMaps.UI.Controls.MapSelectDropdown not found");
            return AccessTools.Method(type, "FilterByInternalMapName", new[] { typeof(string) })
                ?? throw new MissingMethodException(type.FullName, "FilterByInternalMapName");
        }

        private static void Prefix(object __instance, ref string internalMapName)
        {
            if (string.IsNullOrEmpty(internalMapName)) return;
            var requested = internalMapName;
            var extended = ExpandedArtworkDefinitions.ResolveAlias(internalMapName);
            if (extended != internalMapName)
            {
                internalMapName = extended;
                return;
            }

            // FactoryClassic deliberately uses the same factory4_day/factory4_night IDs as vanilla.
            // The extension now ships a static Factory Classic MapDef/art set, so no runtime
            // NavMesh map generation is needed. Redirect only when FactoryClassic proves that
            // Classic is selected/loaded and the packaged map files are intact.
            if (FactoryClassicBridge.IsFactory(internalMapName))
            {
                var classicChosen = FactoryClassicBridge.IsClassicChosen;
                var classicLoaded = FactoryClassicBridge.ClassicSceneLoaded;
                var assetsReady = FactoryClassicAssets.Available;

                if ((classicLoaded || classicChosen) && assetsReady)
                    internalMapName = FactoryClassicAlias;
                else if ((classicLoaded || classicChosen) && !assetsReady)
                    Plugin.Log?.LogWarning($"Factory Classic is selected, but DynamicMaps Extended's packaged Factory Classic map is incomplete. {FactoryClassicAssets.Describe()}");

                DebugOnce($"factory|{requested}|{classicChosen}|{classicLoaded}|{assetsReady}|{internalMapName}", $"Alias decision: requested={requested}, factoryClassic chosen={classicChosen}, loaded={classicLoaded}, packagedAssetsReady={assetsReady}, result={internalMapName}");
                return;
            }

            var normalized = internalMapName.Trim().ToLowerInvariant();
            string alias = null;
            string pluginGuid = null;

            switch (normalized)
            {
                case "interchange":
                    alias = InterchangeAlias;
                    pluginGuid = Plugin.ManimalInterchangeGuid;
                    break;
                case "lighthouse":
                    // No verified Manimal-specific overhead artwork exists yet. Keep DynamicMaps'
                    // native Lighthouse MapDef rather than falsely labelling old artwork as a backport map.
                    // Live player/extract/quest markers still come from the actual raid.
                    DebugOnce($"lighthouse|{requested}", $"Alias decision: requested={requested}, Manimal Lighthouse uses native DynamicMaps artwork until matching geometry is verified.");
                    return;
                case "laboratory":
                    alias = LabsAlias;
                    pluginGuid = Plugin.ManimalLabsGuid;
                    break;
                default:
                    // Icebreaker has its own real location ID, so no alias is required.
                    DebugOnce($"unchanged|{requested}", $"Alias decision: requested={requested}, not a shared-ID map; unchanged.");
                    return;
            }

            var mv = MapVariantsBridge.Resolve(internalMapName);
            if (mv.ApiAvailable)
            {
                var backportPresent = PluginDetection.Loaded(pluginGuid) && AliasAssetsReady(alias);

                if (mv.Managed)
                {
                    // MapVariants is authoritative for maps it manages. Never infer a backport
                    // merely because the backport plugin is installed.
                    if (mv.Decided && mv.IsBackport && backportPresent)
                        internalMapName = alias;
                    else if (mv.Decided && mv.IsBackport && !backportPresent)
                        Plugin.Log?.LogWarning($"MapVariants selected the backport for {requested}, but {pluginGuid} is not loaded. DynamicMaps will stay on the original map definition.");

                    DebugOnce($"managed|{requested}|{mv}|{pluginGuid}|{backportPresent}|{internalMapName}", $"Alias decision: requested={requested}, MapVariants({mv}), backportPlugin={pluginGuid}:{backportPresent}, result={internalMapName}");
                    return;
                }

                // Current Manimal Labs replaces the laboratory location rather than exposing a
                // MapVariants choice. Preserve that compatibility only for Labs. Interchange and
                // every MapVariants-managed shared-ID map remain strictly variant-driven.
                if (normalized == "laboratory" && backportPresent)
                    internalMapName = alias;

                DebugOnce($"unmanaged|{requested}|{mv}|{pluginGuid}|{backportPresent}|{internalMapName}", $"Alias decision: requested={requested}, MapVariants({mv}), unmanaged fallback={(normalized == "laboratory")}, backportPlugin={pluginGuid}:{backportPresent}, result={internalMapName}");
                return;
            }

            // Defensive compatibility only when the MapVariants API itself cannot be resolved.
            // MapVariants is a hard dependency, so this should normally never execute.
            var backportLoaded = PluginDetection.Loaded(pluginGuid) && AliasAssetsReady(alias);
            if (normalized == "laboratory" && backportLoaded)
                internalMapName = alias;

            DebugOnce($"noapi|{requested}|{pluginGuid}|{backportLoaded}|{internalMapName}", $"Alias decision: requested={requested}, MapVariants API unavailable, labsFallback={(normalized == "laboratory")}, backportPlugin={pluginGuid}:{backportLoaded}, result={internalMapName}");
        }

        private static bool AliasAssetsReady(string alias)
        {
            if (string.Equals(alias, InterchangeAlias, StringComparison.OrdinalIgnoreCase))
                return ExtensionAssetAvailability.ManimalInterchangeReady;
            if (string.Equals(alias, LabsAlias, StringComparison.OrdinalIgnoreCase))
                return ExtensionAssetAvailability.ManimalLabsReady;
            if (string.Equals(alias, FactoryClassicAlias, StringComparison.OrdinalIgnoreCase))
                return FactoryClassicAssets.Available;
            return true;
        }
    }
}
