using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace DynamicMapsExtended
{
    [Serializable] internal sealed class ArtworkEntry
    {
        public string map;
        public string variant;
        public string floor;
        public string sourceSuffix;
        public string abstractPath;
        public string satellitePath;
        public string recommended;
        public bool native;
    }

    [Serializable] internal sealed class ArtworkCatalogData
    {
        public int version;
        public ArtworkEntry[] entries;
    }

    internal static class ArtworkCatalog
    {
        internal static ArtworkEntry[] Entries { get; private set; } = Array.Empty<ArtworkEntry>();

        internal static void Initialize()
        {
            var path = Path.Combine(Plugin.MapsRoot, "ARTWORK-CATALOG.json");
            var data = JsonUtility.FromJson<ArtworkCatalogData>(File.ReadAllText(path));
            if (data == null || data.version != 1 || data.entries == null)
                throw new InvalidDataException("Unsupported bundled artwork catalogue.");
            Entries = data.entries;
        }

        internal static ArtworkEntry Find(string source)
        {
            var normalized = source.Replace('\\', '/');
            foreach (var e in Entries)
                if (normalized.EndsWith(e.sourceSuffix, StringComparison.OrdinalIgnoreCase))
                    return e;
            return null;
        }

        internal static string Local(string relative)
        {
            if (string.IsNullOrEmpty(relative)) return null;
            if (Path.IsPathRooted(relative) || relative.Contains(":") || relative.Contains(".."))
                throw new InvalidDataException("Invalid bundled artwork path: " + relative);
            var absolute = Path.GetFullPath(Path.Combine(Plugin.ExtensionRoot, relative.Replace('/', Path.DirectorySeparatorChar)));
            var root = Path.GetFullPath(Plugin.ExtensionRoot).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            if (!absolute.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Artwork path escapes extension root.");
            return absolute;
        }

        internal static bool Available(string relative)
        {
            var p = Local(relative);
            return p != null && File.Exists(p) && File.Exists(Path.ChangeExtension(p, ".pyramid.json"));
        }
    }
}
