# DynamicMaps Extended v1.5.0

This release consolidates the DynamicMaps Extended work for SPT 4.1.x and DynamicMaps 1.2.1.

### Main changes

- Final map artwork matrix: only meaningful Vanilla / Satellite / Abstract choices are shown.
- Fixed the Icebreaker 16-floor slider and floor synchronization.
- Added fast asynchronous map previews plus a cached ~3K active-floor warm atlas.
- Added earlier progressive high-resolution refinement for zoomed maps.
- Added/updated support for Factory Classic, Icebreaker, Manimal Interchange, Manimal Labs, Reserve Satellite and Labyrinth.
- No runtime downloads and no Fika synchronization patches.

### Validation

Final debug testing confirmed Icebreaker levels 0–15 were selected across the full scrollbar range and high-resolution refinement activated for tested raster maps including Woods and Icebreaker.

### Asset licensing

The public source does not include prepared raster/tile artwork whose public redistribution rights have not been confirmed. See `THIRD-PARTY.md`.
