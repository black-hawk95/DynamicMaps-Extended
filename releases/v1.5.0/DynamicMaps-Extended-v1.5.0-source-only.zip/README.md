# DynamicMaps Extended v1.5.0

Extension for **DynamicMaps 1.2.1** on **SPT 4.1.x**. It keeps DynamicMaps responsible for player tracking, markers, minimap, coordinates and normal map behavior, while adding additional map variants and verified alternate artwork support.

## Highlights

- DynamicMaps Vanilla / Satellite / Abstract artwork switching where meaningful artwork actually exists
- Per-map artwork overrides in F12
- Factory Classic support
- Icebreaker support with a repaired 16-level floor slider (levels 0–15)
- Manimal Interchange and Labs support
- Reserve Satellite alias with its own calibration
- Labyrinth Satellite support
- In-raid artwork switching
- Local asynchronous raster loading
- ~3K whole-floor warm atlas for the active floor
- Progressive high-resolution tile refinement while zooming
- Bounded tile cache and slow-frame protection
- No runtime downloads
- No Fika packets or custom multiplayer synchronization

## Artwork matrix

| Map | Available artwork |
| --- | --- |
| Ground Zero | DynamicMaps Vanilla, Satellite |
| Customs | DynamicMaps Vanilla, Satellite |
| Factory | DynamicMaps Vanilla, Satellite, Abstract |
| Factory Classic | Factory Classic Artwork only |
| Woods | DynamicMaps Vanilla, Satellite, Abstract |
| Interchange | DynamicMaps Vanilla, Satellite |
| Interchange (Manimal) | DynamicMaps Vanilla, Satellite, Abstract |
| The Lab | DynamicMaps Vanilla, Satellite |
| Lighthouse | DynamicMaps Vanilla only |
| Reserve | DynamicMaps Vanilla, Satellite |
| Shoreline | DynamicMaps Vanilla, Satellite |
| Streets | DynamicMaps Vanilla, Abstract |
| Labyrinth | DynamicMaps Vanilla, Satellite |
| Icebreaker | Bundled Icebreaker artwork |

Single-choice maps remain visible in F12 and are labelled **(Only Available)** rather than exposing duplicate choices.

## v1.5.0 performance behavior

Raster maps first load a lightweight preview asynchronously. The current/default floor can then be upgraded to a cached ~3072-pixel whole-floor warm atlas. When zooming further, local `.tiles` packs progressively replace the visible region with native high-resolution tiles.

High-resolution work is asynchronous, does not perform a giant full-map native decode, is delayed away from the initial map-open frame, and uses bounded cache/decode limits. The current floor becomes clearer quickly while deep zoom still has access to the original tile resolution.

## Icebreaker floor selector

Icebreaker contains 16 valid levels. v1.5.0 repairs the live DynamicMaps level list to **0 through 15**, synchronizes the scrollbar to the selected floor, and rejects impossible floor values without changing the normal selector behavior of other maps.

## Requirements

- SPT 4.1.x
- DynamicMaps 1.2.1
- MapVariants
- Related map/backport mods only for the variants you use

Fika is supported. DynamicMaps Extended detects Fika only for diagnostics and does not send or patch Fika synchronization packets.

## Installation

Install the packaged `DynamicMaps-Extended` folder under:

```text
BepInEx/plugins/
```

To uninstall, delete that one folder.

## Building

`build.ps1` is the local release builder. It does not download assets and it does not install anything into SPT. It expects the prepared artwork asset set used by the project, validates the local assets, compiles the DLL, and creates:

```text
DynamicMaps-Extended-1.5.0-SPT4.1.zip
```

### Public repository asset note

The C# source is published here, but some prepared raster/tile artwork used by the private/local build is **not included in this public repository** because redistribution rights for every exact raster source have not been established. See `THIRD-PARTY.md`.

## License

The C# source code is MIT licensed. Third-party artwork keeps its own license/terms and is not relicensed as MIT.
