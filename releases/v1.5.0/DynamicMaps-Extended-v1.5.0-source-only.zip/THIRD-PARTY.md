# Third-party artwork and licensing

The C# code in DynamicMaps Extended is covered by this project's MIT license. **Third-party artwork is not relicensed as MIT.**

## DynamicMaps

Source: https://github.com/acidphantasm/SPT-DynamicMaps

DynamicMaps Extended depends on DynamicMaps and does not redistribute its DLL. DynamicMaps remains responsible for map UI, markers, coordinates, player tracking and native Vanilla artwork.

## Tarkov.dev SVG maps

Source: https://github.com/the-hideout/tarkov-dev-svg-maps

The SVG-map repository is licensed under **CC BY-NC-SA 4.0** and carries its own attribution and conditions. The pinned SVG source revision used during development was `5a8b6115d1c0cf56f2ebaac1a96fa5ae3074d178`.

Any derived SVG/abstract artwork must remain under the original CC BY-NC-SA 4.0 terms, including attribution, non-commercial use and share-alike requirements.

## Tarkov.dev raster/tile artwork

Metadata/source capture revision used during development: `the-hideout/tarkov-dev` commit `ef62766bbd7ffb294c7184f9b8bfe8ed0f18320e`.

The private/local development build used raster previews and local `NVTILES2` tile packs prepared from map imagery obtained through Tarkov.dev sources. Availability from `assets.tarkov.dev` does **not** by itself establish public redistribution rights for every underlying raster image. Some artwork is credited to third parties, including TarkovBOT.eu for Icebreaker.

For that reason, those prepared raster/tile assets are **not being added to the public v1.5.0 source repository or a public release asset unless their redistribution rights are confirmed**.

## Factory Classic

Factory Classic artwork was supplied separately for this project and remains subject to its original artwork/source terms.

## Manimal Interchange Abstract runtime copies

The private/local runtime PNG previews and tile packs used for Manimal Interchange Abstract are offline rasterizations of the pinned Tarkov.dev Interchange SVG artwork. They were created to avoid Unity.VectorGraphics rendering incompatibilities and do not invent or redraw the map. The underlying artwork remains subject to its original terms.
